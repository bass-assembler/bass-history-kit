#ifndef NALL_WINDOWS_GUARD_HPP
#define NALL_WINDOWS_GUARD_HPP

#define boolean WindowsBoolean
#define interface WindowsInterface

#else
#undef NALL_WINDOWS_GUARD_HPP

#undef boolean
#undef interface

#endif
